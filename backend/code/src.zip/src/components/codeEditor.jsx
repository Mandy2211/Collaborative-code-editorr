import { useState, useEffect } from "react";
import Prism from "prismjs";
import "prismjs/themes/prism-tomorrow.css"; // Theme similar to VS Code
import "prismjs/components/prism-javascript";
import "prismjs/components/prism-python";
import "prismjs/components/prism-cpp";
import "prismjs/components/prism-java";
import "./index.css";

export default function CodeEditor({ code, setCode, language }) {
  useEffect(() => {
    Prism.highlightAll();
  }, [code, language]);

  return (
    <div className="w-full max-w-2xl">
      {/* Code Input */}
      <textarea
        className="w-full h-40 p-3 bg-gray-800 border border-gray-600 text-white rounded font-mono"
        value={code}
        onChange={(e) => setCode(e.target.value)}
      />

      {/* Syntax Highlighting Display */}
      <pre className="p-4 bg-gray-800 rounded overflow-x-auto">
        <code className={`language-${language}`}>{code}</code>
      </pre>
    </div>
  );
}
