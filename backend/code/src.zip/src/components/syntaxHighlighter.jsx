import { useEffect } from "react";
import Prism from "prismjs";
import "prismjs/themes/prism-tomorrow.css"; // Change the theme if needed

const SyntaxHighlighter = ({ code, language }) => {
  useEffect(() => {
    Prism.highlightAll();
  }, [code]); // Re-run when `code` changes

  return (
    <pre className={`language-${language}`}>
      <code className={`language-${language}`}>{code}</code>
    </pre>
  );
};

export default SyntaxHighlighter;
