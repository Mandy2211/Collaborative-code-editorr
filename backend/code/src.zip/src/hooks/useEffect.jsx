useEffect(() => {
    if (typeof window !== "undefined") {
      setTimeout(() => {
        Prism.highlightAll();
      }, 0);
    }
  }, [code, language]);
  